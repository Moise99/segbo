<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\MOISE\Documents\laravel_project\my_project\segbo\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>